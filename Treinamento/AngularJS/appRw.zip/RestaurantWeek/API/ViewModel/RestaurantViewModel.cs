﻿namespace API.ViewModel
{
    public class RestaurantViewModel
    {
        public int Id { get; set; }      
        public string Nome { get; set; }
    }
}