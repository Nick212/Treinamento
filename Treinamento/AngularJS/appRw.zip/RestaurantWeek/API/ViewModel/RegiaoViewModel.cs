﻿namespace API.ViewModel
{
    public class RegiaoViewModel
    {
        public int Id { get; set; }
        public string Cidade { get; set; }

    }
}
