﻿
(function (angular) {
    var app = angular.module('admin');
    
    var mainController = function ($scope, $routeParams) {};

    app.controller('mainController', ['$scope', '$routeParams', mainController]);
}(angular));