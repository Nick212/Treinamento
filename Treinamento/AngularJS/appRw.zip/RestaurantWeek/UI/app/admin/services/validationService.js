﻿
(function (angular) {
    var app = angular.module('admin');
    app.factory('Validation', [function () {
        var validation = {};
        validation.isCpf = function isCPF(value) {
         
        }
        return validation;
    }]);
}(angular));